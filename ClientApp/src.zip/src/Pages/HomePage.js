
import React from 'react';

const HomePage = () => {
 
    return (
      <div className='container'>Homepage</div>
    );
};

export default HomePage;